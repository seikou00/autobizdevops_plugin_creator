---
name: autodev-plan
description: 将已确认的行为与技术设计转为任务、真实依赖和仓库归属，生成并发布 Plan。
metadata:
  version: v4.0
---

# /autodev-plan — Delivery Plan

默认主会话执行，只生成一份 Plan 输入；writer 生成 `plan.json`、Batch 和人类视图 `PLAN.md`。

## 输入与查证

读取 proposal、specs、design、`.design-contract.lock.json`、`IMPLEMENTATION_SCOPE.json` 与 `UI_CONTEXT.json`，复用已确认事实。只为影响仓库归属或真实依赖的问题补查相关入口；有独立检索价值时才向 `Explore-autodev` 提供具体问题、范围和已有证据，足以规划即停止。

```bash
python -X utf8 "${pluginPath}/skills/scripts/flowlib/read_state_json.py" --feature "${feature}"
```

输入缺失时用 `inspect_skill_contract.py autodev-plan --feature "${feature}" --plain` 获取缺失处理；正常执行无需预读 writer 或门禁源码。

## Plan 输入

使用 `templates/plan-input.json`（`schemaVersion=autodev.plan`）：

- 一个 Task 是同一仓库、单一执行 lane 内可独立验收、独立返工的交付切片。独立功能分别建任务，共享页面、仓库或接口不构成合并理由；同一行为的正常、边界、权限和失败分支放一起。不按文件、方法、断言或场景数量机械拆分；边界难判断时再读 `references/task-planning.md`。
- `id` 为稳定 `TNNN`，`outcome` 写可观察交付结果，`workspace` 写仓库逻辑 ID，`dependsOn` 只写真实前置交付。可选 `components` 仅记录粗粒度组件归属（相对 Git 根），投影为 `scope.modules` 参考；具体编译、测试目录由后续阶段按实际代码确定，无需预测子模块。数组顺序不代表依赖。
- `implementationPoints` 写关键改动与边界，`testPoints` 写需证明的行为及失败路径，`verification.intent` 写一句验收目标；避免重复描述，不预测实现文件、方法、测试命令或 Batch。
- `refs.requirements` / `refs.scenarios` 引用真实 `specs/<capability>/spec.md#REQ-NNN` / `#SCN-NNN`，逐条覆盖本期场景。`refs.api` / `refs.data` 按需填写；每个本期 `D-NNN` 在 `refs.decisions` 中只有一个主交付 Task。其他协作任务引用 API/Data/Scenario，既有范围不得为通过校验而缩小。
- 每个 Task 必须显式填写 `ui`：前端实现任务（UI Task）填写对象，后端任务填写 `null`。`uiRequired` 表示需要前端实现，与是否提供 HTML 或高保真稿无关；无 HTML 使用 `ui.route="spec-driven-ui"`，普通 HTML 使用 `standard-html`，高保真 HTML 使用 `absolute-html`。禁止因缺少 HTML 而省略 `ui` 或填写 `null`。
- 交付页面、前端组件或界面交互的 Task 必须填写 `ui.pages`、`ui.interactions`、`ui.route`；只读页面 interactions 可为空。调用已有接口或处理展示数据的纯前端任务仍归 frontend；同一需求涉及前后端实现时按 lane 分开交付。writer 根据 `ui` 投影 lane，从 UI capability 投影视觉源，从 Spec 的 Source References 投影外部资料，不由模型重复维护这些派生字段。

无 HTML 的前端 Task 可使用以下 `ui` 结构，页面 ID 使用 UI_CONTEXT.json 中的真实引用，不要求绑定视觉源：

```json
{
  "ui": {
    "pages": ["PAGE-001"],
    "interactions": [],
    "route": "spec-driven-ui"
  }
}
```

## 生成、回检与发布

```bash
python -X utf8 "${pluginPath}/skills/scripts/flowlib/plan_writer.py" prepare-plan \
  --feature "${feature}" --code-workspace "<ACTUAL_CODE_GIT_ROOT>" --body-stdin
```

`--code-workspace` 必须是实际 Git 根，多仓库重复传入；单仓库可用逻辑 ID `default`。writer 校验引用、覆盖、设计归属、仓库绑定及 DAG，生成 `reviewing` 的完整计划；失败按结构化问题修正输入，重新 prepare，不手改机器产物。

按 `${pluginPath}/skills/references/review-protocol-plan.md` 做一次 Plan Critic 语义回检：只查交付边界、仓库职责、UI/lane 归属和真实依赖，不重做设计探索。修复后根据 `reviewChanges` 复核受影响任务与依赖；共享需求/设计/范围变化时全量复核。输入与上下文未变且已有通过结论时复用结论，不重复生成或回检。

```bash
python -X utf8 "${pluginPath}/skills/scripts/flowlib/plan_writer.py" publish-plan --feature "${feature}"
python -X utf8 "${pluginPath}/skills/scripts/flowlib/stage_gate.py" validate --stage dev.plan --feature "${feature}"
```

以上命令都通过后，再执行本技能开头状态维护片段中的“技能完成执行”命令。

`publish-plan` 将计划定稿为 `finalized` 并投影 `PLAN.md`；Markdown 不独立维护。定稿后的行为或计划变更走 Plan rollback，执行恢复交由 Code workflow。只有改变已确认行为、公开契约或用户取舍时按 `${pluginPath}/skills/references/ask-user-question.md` 提问；内部拆分与排序自行修正。同一问题修复后仍失败则报告阻断。

简报产物与验证结果，再按 `${pluginPath}/skills/references/ui-continuation-guide.md` 处理阶段完成。
