---
name: autobiz-plugin-skeleton
description: 引导创建和修改 AutoBiz 看板插件（DevClaw 插件）：从业务想法逐步起草配置、把现成技能组装成流程，或增删改已有插件节点。模型提出方案供用户确认，再生成、检查和打包；也支持用户自行填写配置。
metadata:
  version: 1.3.0
---

# 看板插件骨架引导

默认由模型起草配置和技能，用户决定业务含义并确认具体方案。用户不需要先掌握 JSON、节点标识或模块字段。用户明确选择自行填写时，提供骨架和按需解释，等待其完成，避免同时编辑。

## 入口和提问

先根据用户请求和已有材料选择路径，已明确的起点不重复询问。不清楚时问“你现在准备从哪里开始？”：从想法搭建、用现成技能组装、修改已有插件。按上下文推荐，不能无条件推荐从头新建。

读取[分场景引导指南](references/guided-workflows.md)中对应路径：

- **从头搭建**：用途 → 流程草案 → 逐节点职责、产物和完成条件 → 模块 → 配置摘要。
- **现成技能组装**：读取技能和现有流程资料 → 区分节点与辅助能力 → 建议映射和顺序 → 只补缺口 → 导入方案。
- **已有插件修改**：读取源配置和技能 → 明确具体变更 → 检查依赖与兼容性 → 差异摘要；不运行新建流程，不重新选择全部模块。

配置协作方式的首选是“模型起草，我来确认（推荐）”，说明“根据你的回答逐步整理配置，每一步都能调整”；另一项是“我自己填写配置”。用户已经请你代写或修改时直接采用，不重复询问。

- 每轮默认一个主要决定，紧密相关时最多两个问题；给具体建议、理由和必要示例，不把字段清单当问卷。
- 使用当前环境可用且允许使用的选择题工具；不可用时用普通对话。推荐项放首位并标注推荐，遵循工具的选项与自由输入规则。
- 用户已说明或文件已明确的信息直接复用；推导内容标为建议，歧义才提问。保留“已确认／模型建议／待补充”状态。
- 用户不确定时给例子或拆成更小的问题；不默认同意，不编造路径、地址、业务规则或必需产物。
- 显示简短进度，允许返回修改，只重新讨论受影响部分。先讲业务，再按需解释字段。
- 确认具体摘要后写入；已有明确授权覆盖的内容不反复请求许可。最终总结文件改动、检查结果和未解决事项。

## 调用 CLI

```bash
python "<booter>" <命令> --json
```

- `<booter>` 是本文件所在目录的绝对路径。CLI 直接从这个目录的源码运行（入口是目录下的 `__main__.py`），不用切换目录，也不用另外安装；
- 针对已有插件目录的命令加 `-C "<插件目录>"`；
- 退出码：`0` 成功（可能带 warning），`1` 有 error、没有写入任何文件，`2` 用法错误；
- `--json` 输出 `{"ok", "issues": [{level, code, file, pointer, message, hint}], "written": [...]}`。

检查结论以退出码和 `issues` 为准。CLI 会按 Schema、推导规则和契约测试逐项核对，光读配置文件看不全这些，所以不要在 CLI 之外自己下“没问题”的结论。转述 issue 时带上文件和位置，`message`、`hint` 尽量原样给出，用户照着就能找到要改的地方。

## 流程

### 1. 确定方案后，准备目录和模块（仅新建）

先按对应路径梳理业务或技能并确认流程草案，再确定 `plugin_dir`（插件放在哪个目录）。目录需要为空或尚未创建。推荐当前工作区下的 `my-plugin`，也可以给上一级目录下的 `my-plugin`，或让用户在 Other 中填写路径。

运行模块列表。它在新建插件前就可以用：

```bash
python "<booter>" module list --json
```

根据已确认的流程识别相关可选模块，用业务问题解释收益，再询问是否需要；只有启用时读取对应指南并补齐必要信息。没有需求的模块保持关闭，不逐一讲解全部字段。已有插件保留当前模块，仅处理本次变更涉及的部分。

- 对发布单元知识，问“要不要按发布单元带入知识？”。选“要”后按 `guide` 路径读取指南，用「要定的两件事」提问 `knowledge_source`（发布单元知识从哪来）和 `knowledge_assembler`（谁把发布单元知识放进会话）。选项说明取自表里的「怎么写」，在来源问题下附上知识目录优先顺序。按用户已有的知识目录、Git 仓库或 DevClaw 绑定情况推荐来源，组装方默认选插件。Git 地址可以当场提供，也可以留到第 2 步填写。

用 `custom_policy` 单独问「要不要自定义节点的 Agent 运行模式（multi、solo、team、workflow）？」并同时提供以下两个选项。选择题工具不可用时，用普通消息列出相同的两个选项，请用户回复所选项。

| label | description |
|---|---|
| 沿用默认 (Recommended) | 各节点使用 `multi`（多 Agent）。 |
| 自定义运行模式 | 可设置全局默认模式并按节点覆盖。支持 `multi`（多 Agent）、`solo`（单 Agent）、`agent_team`（team，Agent 团队）和 `workflow`（工作流）。 |

选择自定义后生成 `modules/session.json`，在第 2 步讲解如何设置全局默认模式、逐节点覆盖、子代理和工具开关。框架自动生成会话入口，把流程上下文、运行策略和可选的发布单元知识交给 DevClaw。

生成骨架，在命令里为每个选中的可选模块追加一次 `--module <id>`：

```bash
python "<booter>" new "<插件目录>" --skeleton --json
```

自定义运行策略时加 `--module session`。用户想自定义看板名称、文案或目标平台时加 `--module board`。看板的流程名称默认取插件名。

生成后按选择写入配置，并告诉用户改了哪些字段：

- `knowledge_source` 选了 Git 仓库并给了地址：填进 `modules/knowledge.json` 的 `source.url`；没给地址就留着占位，等用户填；
- `knowledge_source` 选了随插件打包或由 DevClaw 提供：删掉 `modules/knowledge.json` 中的整个 `source`；
- `knowledge_assembler` 选了插件或 DevClaw：`assembly.assembler` 分别写 `plugin` 或 `devclaw`；

### 2. 起草、确认并写入配置

读[配置填写指南](references/config-guide.md)和[建模指南](modeling-guide.md)，依据分场景指南完成业务决定。只在需要时按 `module list` 返回的 `guide` 路径读取模块说明。

模型负责推导合法的插件和节点标识、阶段、顺序及文件引用；用户重点确认流程、职责、产物和模块行为。必需产物仅写每次确实交付的文件；完成质量要求写进技能正文。说明当前流程按阶段线性推进，不能承诺任意分支或跳过节点。

新建时展示名称、用途、目录、节点职责与产物、启用模块和技能来源；修改时展示前后差异及受影响依赖。技术字段表或 JSON 按需展开。未确定的必填信息继续引导，不能把占位当作完成。

确认后将草案写入源配置。用户选择自行填写时，提供骨架和相关说明，等其填写完成；用户问到哪个字段就解释哪个。

### 3. 检查配置

模型写入后或用户说填好了，运行：

```bash
python "<booter>" -C "<插件目录>" lint --json
```

- `TODO_FIELD` 是还没填的占位：按 `file`、`pointer` 列出来，用户一眼就能看到还差哪几处；
- 其他 error（例如 `SEQ_DUP`、`SEQ_STAGE_ORDER`、`SKILL_SHARED`、`ARTIFACT_REF_UNKNOWN`）：转述 `message` 和 `hint`，指出文件和位置，需要时查[配置填写指南](references/config-guide.md)或对应模块的说明；
- 只剩 warning 时可以往下走：`SKILL_MISSING` 下一步处理；artifactSync 简述的 `TODO_FIELD` 打包前填完就行。

格式、编号和明确的引用错误由模型按已确认方案修正，再 lint；涉及业务歧义时只问对应问题。自行填写模式下给出修正建议，避免覆盖用户编辑。

### 4. 节点技能

| id | 要决定什么 | 推荐 | 其他选项 |
|---|---|---|---|
| `skill_source` | 节点技能从哪里来 | 已知来源直接复用；有技能优先导入，缺少技能推荐模型起草并由用户审阅 | 用户自行编写；部分导入、部分起草 |

**导入已有技能**：如果 `modules/session.json` 引用了子代理文件，再问一下 agents 目录在哪（常见的是与技能集合同级的 `agents/`）。然后运行：

```bash
python "<booter>" -C "<插件目录>" add skills --from "<技能集合目录>" [--agents "<agents 目录>"] --json
```

- 这条命令导入技能的同时会生成插件：节点技能按阶段挪进 `skills/autobiz/`、`skills/autodev/`、`skills/autoops/`，正文里对旧路径的引用一并改掉（列在 `changes.skills.moved`），还没有技能的节点生成空白 `SKILL.md`；
- 技能目录名就是技能名，要与 `workflow.json` 中节点的 `skill` 一致。导入后仍然报 `SKILL_MISSING`，多半是名字没对上，告诉用户是哪个节点；
- `SKILL_REF_DANGLING` 表示技能正文引用的文件在插件里找不到：技能自己的 `templates/`、`references/`、`scripts/`，或者 `${pluginPath}/hooks/…` 这类放在原插件根目录、由技能直接调用的脚本。`add skills` 只搬技能集合目录，原插件根目录 `hooks/` 下的脚本要用户自己拷到插件的 `hooks/`。把缺的文件按技能列给用户，问清楚来源目录，拷完再跑 `doctor` 确认不再报；指的是用户工程里的路径时可以忽略；
- `SKILL_REF_ABSOLUTE` 表示技能正文里写死了绝对路径（例如 `/root/.openclaw/workspace/skills/…`），换一台机器就找不到。`hint` 里列出了插件中同名的文件时，建议用户改成那个 `${pluginPath}/…` 路径，用户同意后再改；
- `LEGACY_ENTRY_REF` 表示技能正文里残留了旧的状态命令（`update_state.py`、`hooks/update_checkpoint.py` 等）。现在节点状态由技能开头的片段统一维护，这些行留着会让状态被重复推进或推进错。把行号和所在小节告诉用户，用户同意后再删。

**补齐缺失技能**：运行 `doctor --json`，检查 `changes.skills.created`。依据已确认的节点职责、产物和完成条件，逐个起草技能供用户审阅后写入；用户选择自行编写时再等用户写完。不能用通用空话替代具体步骤。已有完整技能只修改本次必要部分：

- frontmatter 的 `description`：写“做什么；在什么情况下使用”。看板上的节点描述也取自这里，写清楚了，看板使用者也能看懂这一步在干什么；
- 正文：这个节点的工作步骤、要产出哪些文件（与 `outputs` 一致）、做到什么程度才算完成（例如测试通过、评审结论明确）；
- 开头 `<!-- plugin workflow: begin state -->` 到 `<!-- plugin workflow: end state -->` 之间是状态维护片段，由脚手架按 `workflow.json` 写入，节点靠它推进状态。这一段不要动，正文里也不用再写调用 `update_state.py` 的命令；
- 参考资料放进技能目录的 `references/`，脚本放进 `scripts/`，并在正文里写明什么时候用哪个文件。

### 5. 打包

新建交付需要打包时，在技能内容完整后运行；已有插件仅请求修改时，先 doctor 和 check，用户要求打包才执行 package：

```bash
python "<booter>" -C "<插件目录>" doctor --json
python "<booter>" -C "<插件目录>" package --json
```

- 先跑 `doctor`，是因为技能的 `description` 会编译进看板配置，改过之后不重新生成，`package` 会报 `BUILD_STALE`；
- `package` 会先做完整检查。`TODO_PLACEHOLDER` 说明还有没填的 `[TODO: …]`（空白技能的 `description`、artifactSync 的简述等），`LEGACY_ENTRY_REF` 说明正文里还有旧状态命令。转述位置，请用户改完，再从 `doctor` 重来；
- 成功后告诉用户 zip 在哪：`package.path` 是相对插件目录的路径（默认 `dist/<plugin.id>-<version>.zip`），可以直接导入 DevClaw。每打一次包，版本号自动加一。

### 之后微调文案

用户看过生成结果，想改改对话提示或看板上的文字时，不用为此往核心配置里加字段，直接改生成文件中的这些文字即可，之后的 `doctor`、`package` 都会保留：

| 文件 | 可以改的字段 |
|---|---|
| `plugin.json` | `name`、`description` |
| `board_core/board_config.json` | 各平台（`darwin`、`linux`、`win32`）的 `dialog_tips`、`system_prompt_inject`，每个平台要分别改 |
| `runtime/config/board.json` | `template.label`、`template.description`，`stateLabels` 中的状态名，节点的 `description`，`nextAction` 各状态下的 `userMessage`、`dialogTips` |

这些文字不影响流程，所以放开给用户改，文件的其余部分仍按核心配置生成。以后改了节点名、增删了节点，用户改过的文字会保留，没改过的跟着更新；如果某段改过的文字本身也受到了影响，`doctor` 会报 `CUSTOMIZED_STALE`，提醒用户看看是否还合适。改了这些字段以外的内容会报 `DRIFT_GENERATED`，说明那部分应该回到核心配置里改。

## 边界

- 配置和技能的业务决定归用户；默认模型起草并解释建议，依据已确认的具体方案和已有授权写入，写完说明改了哪里；自行填写模式避免并发覆盖用户内容；
- `plugin.json`、`board_core/`、`runtime/`、`.scaffold/`、`hooks/artifact_guard.py` 由脚手架生成和维护：手改的内容会在下次生成时被覆盖，或者被检查当作漂移拦下。用户想改行为，就改核心配置；只是调文案，按「之后微调文案」改那几个字段；
- 技能开头的状态维护片段是技能和运行框架之间的约定，改坏了节点就推进不了，不要改，也不要用别的办法绕过检查；
- `doctor` 的 `--force`、`--allow-id-change`、`--allow-layout-change`、`--allow-major-upgrade` 是放行开关：会覆盖被改过的托管文件，或改掉发布后不该改的标识。只在用户看过对应的 issue、明确同意后才加。
